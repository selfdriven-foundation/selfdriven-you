'use strict';

var entityos = require('entityos');
var factory  = require('./infrastructurefactory-keri-witness');

factory.init({});

entityos.add(
{
    name: 'util-end',
    code: function (response)
    {
        const resolve = entityos.get({ scope: 'keri-witness', context: '_resolve' });
        if (resolve) { resolve(response); }
    }
});

exports.handler = async function (event)
{
    return new Promise(function (resolve)
    {
        entityos.set({ scope: 'keri-witness', context: '_resolve', value: resolve });
        entityos.set({ scope: '_event', value: event });

        entityos.set(
        {
            scope: '_settings',
            value:
            {
                infrastructure:
                {
                    aws:
                    {
                        region: process.env.AWS_REGION || 'ap-southeast-2',
                        access:
                        {
                            id:     process.env.AWS_ACCESS_KEY_ID     || 'iam-role',
                            secret: process.env.AWS_SECRET_ACCESS_KEY || 'iam-role'
                        }
                    }
                },
                witness:
                {
                    aid:        process.env.WITNESS_AID,
                    publicKey:  process.env.WITNESS_PUBLIC_KEY,
                    privateKey: process.env.WITNESS_PRIVATE_KEY,
                    table:      process.env.WITNESS_TABLE || 'keri-witness-kel'
                }
            }
        });

        entityos.invoke('util-keri-witness-route');
    });
};
