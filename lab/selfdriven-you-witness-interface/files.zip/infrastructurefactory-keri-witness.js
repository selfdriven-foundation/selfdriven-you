'use strict';

var entityos = require('entityos');
var _         = require('lodash');
var crypto    = require('crypto');

/*
 * infrastructurefactory-keri-witness.js
 *
 * KERI witness service — zero external KERI dependencies.
 * All cryptography via Node.js built-in `crypto` (Ed25519, SHA-256).
 * Storage: DynamoDB (key event log per AID).
 *
 * Routes:
 *   POST /         — receive key event + sigs, validate, store, return receipt
 *   GET  /aid      — return this witness's AID and public key
 *   GET  /kel/:aid — return full KEL for a controller AID
 *   GET  /health   — health / liveness check
 *
 * Event body (POST /):
 *   { "event": { ...keri_event... }, "sigs": ["0B<base64url-sig>", ...] }
 *
 * CESR encoding supported (no-dep, built-in):
 *   - 'B'  prefix (1-char code) → 32-byte Ed25519 verification key (non-transferable)
 *   - 'D'  prefix (1-char code) → 32-byte Blake3/SHA-256 next-key digest
 *   - 'E'  prefix (1-char code) → 32-byte SAID (self-addressing identifier)
 *   - '0B' prefix (2-char code) → 64-byte Ed25519 signature
 *
 * SAID computation uses SHA-256 (blake3 requires external dep — not used here).
 * SAIDs are therefore prefixed 'E' matching the SHA-256 derivation code.
 */

// ─── DER prefixes (Node.js crypto needs DER-wrapped keys for Ed25519) ────────
var DER_SPKI_PREFIX   = Buffer.from('302a300506032b6570032100', 'hex');  // SubjectPublicKeyInfo
var DER_PKCS8_PREFIX  = Buffer.from('302e020100300506032b657004220420', 'hex'); // PKCS#8 private

module.exports =
{
    VERSION: '1.0.0',

    init: function (param)
    {
        // ── 1. AWS / DynamoDB config ──────────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-get-config',
            code: function ()
            {
                const settings = entityos.get({ scope: '_settings' });

                const config =
                {
                    region: _.get(settings, 'infrastructure.aws.region',
                             process.env.AWS_REGION || 'ap-southeast-2')
                };

                const accessId = _.get(settings, 'infrastructure.aws.access.id');
                if (accessId && accessId !== 'iam-role')
                {
                    config.credentials =
                    {
                        accessKeyId:     accessId,
                        secretAccessKey: _.get(settings, 'infrastructure.aws.access.secret')
                    };
                }

                return config;
            }
        });

        // ── 2. Witness settings (AID, keys, table) ────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-get-settings',
            code: function ()
            {
                const settings = entityos.get({ scope: '_settings' });
                return {
                    aid:       _.get(settings, 'witness.aid',       process.env.WITNESS_AID),
                    publicKey: _.get(settings, 'witness.publicKey', process.env.WITNESS_PUBLIC_KEY),
                    privateKey:_.get(settings, 'witness.privateKey',process.env.WITNESS_PRIVATE_KEY),
                    table:     _.get(settings, 'witness.table',     process.env.WITNESS_TABLE || 'keri-witness-kel'),
                    region:    _.get(settings, 'infrastructure.aws.region', process.env.AWS_REGION || 'ap-southeast-2')
                };
            }
        });

        // ── 3. HTTP router ────────────────────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-route',
            code: function ()
            {
                const event = entityos.get({ scope: '_event' });

                const method  = (_.get(event, 'requestContext.http.method')
                    || _.get(event, 'httpMethod') || 'GET').toUpperCase();

                const rawPath = (_.get(event, 'requestContext.http.path')
                    || _.get(event, 'path') || '/').replace(/\/$/, '') || '/';

                console.log('[keri-witness] ' + method + ' ' + rawPath);

                if (method === 'GET'  && rawPath === '/health')
                {
                    entityos.invoke('util-keri-witness-health');
                }
                else if (method === 'GET' && rawPath === '/aid')
                {
                    entityos.invoke('util-keri-witness-info');
                }
                else if (method === 'GET' && rawPath.startsWith('/kel/'))
                {
                    entityos.invoke('util-keri-witness-kel-query');
                }
                else if (method === 'POST' && rawPath === '/')
                {
                    entityos.invoke('util-keri-witness-event-receive');
                }
                else if (method === 'OPTIONS')
                {
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json', { body: {}, status: 200 }));
                }
                else
                {
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                            { body: { error: 'not_found', path: rawPath }, status: 404 }));
                }
            }
        });

        // ── 4. GET /health ────────────────────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-health',
            code: function ()
            {
                const ws = entityos.invoke('util-keri-witness-get-settings');
                entityos.invoke('util-end',
                    entityos.invoke('util-response-json',
                    {
                        body:
                        {
                            status:    'ok',
                            service:   'keri-witness',
                            version:   '1.0.0',
                            aid:       ws.aid || 'unconfigured',
                            timestamp: new Date().toISOString()
                        },
                        status: 200
                    }));
            }
        });

        // ── 5. GET /aid ───────────────────────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-info',
            code: function ()
            {
                const ws = entityos.invoke('util-keri-witness-get-settings');
                if (!ws.aid)
                {
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                            { body: { error: 'witness_not_configured' }, status: 500 }));
                    return;
                }

                entityos.invoke('util-end',
                    entityos.invoke('util-response-json',
                    {
                        body:
                        {
                            aid:       ws.aid,
                            publicKey: ws.publicKey,
                            service:   'keri-witness',
                            version:   '1.0.0'
                        },
                        status: 200
                    }));
            }
        });

        // ── 6. GET /kel/:aid ─────────────────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-kel-query',
            code: function ()
            {
                const event   = entityos.get({ scope: '_event' });
                const rawPath = _.get(event, 'requestContext.http.path')
                    || _.get(event, 'path') || '';

                // /kel/<aid>[/<sn>]
                const parts = rawPath.replace(/^\/kel\//, '').split('/');
                const aid   = parts[0];
                const snStr = parts[1];

                if (!aid)
                {
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                            { body: { error: 'aid_required' }, status: 400 }));
                    return;
                }

                entityos.set({ scope: 'keri-witness', context: 'queryAid', value: aid });
                entityos.set({ scope: 'keri-witness', context: 'querySn',  value: snStr });

                entityos.invoke('util-keri-witness-kel-full-get');
            }
        });

        // ── 7. POST / — receive key event ────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-event-receive',
            code: function ()
            {
                const event  = entityos.get({ scope: '_event' });
                let   raw    = _.get(event, 'body', '');

                if (_.get(event, 'isBase64Encoded'))
                {
                    raw = Buffer.from(raw, 'base64').toString('utf8');
                }

                let parsed;
                try { parsed = JSON.parse(raw); }
                catch (e)
                {
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                            { body: { error: 'invalid_json', message: e.message }, status: 400 }));
                    return;
                }

                const keriEvent = _.get(parsed, 'event');
                const sigs      = _.get(parsed, 'sigs', []);

                // Basic field guards
                const required = ['v', 't', 'd', 'i', 's', 'k', 'kt'];
                const missing  = required.filter(function (f) { return !keriEvent || keriEvent[f] === undefined; });
                if (missing.length)
                {
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                        {
                            body: { error: 'missing_fields', fields: missing },
                            status: 400
                        }));
                    return;
                }

                if (!sigs.length)
                {
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                            { body: { error: 'sigs_required' }, status: 400 }));
                    return;
                }

                // Store for chained methods
                entityos.set({ scope: 'keri-witness', context: 'inboundEvent', value: keriEvent });
                entityos.set({ scope: 'keri-witness', context: 'inboundSigs',  value: sigs });

                console.log('[keri-witness] event t=' + keriEvent.t + ' i=' + keriEvent.i + ' s=' + keriEvent.s);

                entityos.invoke('util-keri-witness-event-validate-said');
            }
        });

        // ── 8. Validate SAID ─────────────────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-event-validate-said',
            code: function ()
            {
                const keriEvent = entityos.get({ scope: 'keri-witness', context: 'inboundEvent' });

                const computed  = entityos.invoke('util-keri-witness-said-compute', keriEvent);
                const claimed   = keriEvent.d;

                if (computed !== claimed)
                {
                    console.log('[keri-witness] SAID mismatch — computed=' + computed + ' claimed=' + claimed);
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                        {
                            body: { error: 'said_mismatch', computed: computed, claimed: claimed },
                            status: 400
                        }));
                    return;
                }

                console.log('[keri-witness] SAID ✓ ' + computed);
                entityos.invoke('util-keri-witness-kel-last-get');
            }
        });

        // ── 9. Get last KEL event from DynamoDB ───────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-kel-last-get',
            code: function ()
            {
                const keriEvent = entityos.get({ scope: 'keri-witness', context: 'inboundEvent' });
                const ws        = entityos.invoke('util-keri-witness-get-settings');
                const aid       = keriEvent.i;

                const { DynamoDBClient, QueryCommand } = require('@aws-sdk/client-dynamodb');
                const client = new DynamoDBClient(entityos.invoke('util-keri-witness-get-config'));

                // Query for the last event (highest sn) for this AID
                client.send(new QueryCommand(
                {
                    TableName:              ws.table,
                    KeyConditionExpression: 'aid = :aid',
                    ExpressionAttributeValues: { ':aid': { S: aid } },
                    ScanIndexForward:       false,   // descending — latest first
                    Limit:                  1
                }))
                .then(function (response)
                {
                    const lastItem = _.get(response, 'Items[0]');
                    entityos.set({ scope: 'keri-witness', context: 'lastItem', value: lastItem || null });
                    entityos.invoke('util-keri-witness-event-validate-sn');
                })
                .catch(function (err)
                {
                    console.error('[keri-witness] QueryCommand error:', err);
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                            { body: { error: 'storage_error', message: err.message }, status: 500 }));
                });
            }
        });

        // ── 10. Validate sequence number ──────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-event-validate-sn',
            code: function ()
            {
                const keriEvent = entityos.get({ scope: 'keri-witness', context: 'inboundEvent' });
                const lastItem  = entityos.get({ scope: 'keri-witness', context: 'lastItem' });
                const eventType = keriEvent.t;
                const claimedSn = parseInt(keriEvent.s, 16) || parseInt(keriEvent.s, 10) || 0;

                if (eventType === 'icp')
                {
                    // Inception event — AID must not already exist
                    if (lastItem)
                    {
                        entityos.invoke('util-end',
                            entityos.invoke('util-response-json',
                            {
                                body: { error: 'aid_already_exists', aid: keriEvent.i },
                                status: 409
                            }));
                        return;
                    }
                    if (claimedSn !== 0)
                    {
                        entityos.invoke('util-end',
                            entityos.invoke('util-response-json',
                                { body: { error: 'sn_must_be_zero_for_icp' }, status: 400 }));
                        return;
                    }
                }
                else
                {
                    // Subsequent event — must follow on from last
                    if (!lastItem)
                    {
                        entityos.invoke('util-end',
                            entityos.invoke('util-response-json',
                            {
                                body: { error: 'aid_not_found', message: 'No inception event found for this AID.' },
                                status: 404
                            }));
                        return;
                    }

                    const lastSn  = parseInt(_.get(lastItem, 'sn.N', '0'), 10);
                    const expectSn = lastSn + 1;

                    if (claimedSn !== expectSn)
                    {
                        entityos.invoke('util-end',
                            entityos.invoke('util-response-json',
                            {
                                body: { error: 'sn_out_of_order', expected: expectSn, received: claimedSn },
                                status: 400
                            }));
                        return;
                    }
                }

                console.log('[keri-witness] sn ✓ ' + claimedSn);
                entityos.invoke('util-keri-witness-event-validate-sig');
            }
        });

        // ── 11. Validate signatures ───────────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-event-validate-sig',
            code: function ()
            {
                const keriEvent = entityos.get({ scope: 'keri-witness', context: 'inboundEvent' });
                const sigs      = entityos.get({ scope: 'keri-witness', context: 'inboundSigs' });
                const lastItem  = entityos.get({ scope: 'keri-witness', context: 'lastItem' });
                const eventType = keriEvent.t;

                // Determine the signing keys:
                // icp / ixn — use current keys from this event (k)
                // rot — use current keys from the *previous* event to verify the rotation auth
                let signingKeys;
                if (eventType === 'rot' && lastItem)
                {
                    // Previous event's keys are stored as a JSON string
                    const prevEvent = JSON.parse(_.get(lastItem, 'eventJson.S', '{}'));
                    signingKeys = prevEvent.k || keriEvent.k;
                }
                else
                {
                    signingKeys = keriEvent.k;
                }

                // The signed datum is the SAID of the event (as UTF-8 bytes)
                const saidBuffer = Buffer.from(keriEvent.d, 'utf8');

                // Threshold: kt may be "1" or "2" etc.
                const threshold = parseInt(keriEvent.kt, 10) || 1;
                let   verified  = 0;

                for (let i = 0; i < sigs.length && i < signingKeys.length; i++)
                {
                    const rawSig = entityos.invoke('util-keri-witness-cesr-sig-decode',  sigs[i]);
                    const rawKey = entityos.invoke('util-keri-witness-cesr-key-decode', signingKeys[i]);

                    if (!rawSig || !rawKey)
                    {
                        console.log('[keri-witness] could not decode sig or key at index ' + i);
                        continue;
                    }

                    const valid = entityos.invoke('util-keri-witness-ed25519-verify',
                        { message: saidBuffer, signature: rawSig, publicKey: rawKey });

                    if (valid)
                    {
                        verified++;
                        console.log('[keri-witness] sig[' + i + '] ✓');
                    }
                    else
                    {
                        console.log('[keri-witness] sig[' + i + '] ✗ invalid');
                    }
                }

                if (verified < threshold)
                {
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                        {
                            body: { error: 'threshold_not_met', required: threshold, verified: verified },
                            status: 400
                        }));
                    return;
                }

                console.log('[keri-witness] sigs ✓ ' + verified + '/' + threshold + ' threshold met');
                entityos.invoke('util-keri-witness-kel-event-save');
            }
        });

        // ── 12. Save event to DynamoDB ────────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-kel-event-save',
            code: function ()
            {
                const keriEvent = entityos.get({ scope: 'keri-witness', context: 'inboundEvent' });
                const ws        = entityos.invoke('util-keri-witness-get-settings');
                const snInt     = parseInt(keriEvent.s, 16) || parseInt(keriEvent.s, 10) || 0;

                const { DynamoDBClient, PutItemCommand } = require('@aws-sdk/client-dynamodb');
                const client = new DynamoDBClient(entityos.invoke('util-keri-witness-get-config'));

                const item =
                {
                    aid:       { S: keriEvent.i },
                    sn:        { N: String(snInt) },
                    said:      { S: keriEvent.d },
                    eventType: { S: keriEvent.t },
                    eventJson: { S: JSON.stringify(keriEvent) },
                    dt:        { S: new Date().toISOString() }
                };

                client.send(new PutItemCommand(
                {
                    TableName:           ws.table,
                    Item:                item,
                    ConditionExpression: 'attribute_not_exists(aid) AND attribute_not_exists(sn)'
                }))
                .then(function ()
                {
                    console.log('[keri-witness] KEL saved aid=' + keriEvent.i + ' sn=' + snInt + ' said=' + keriEvent.d);
                    entityos.invoke('util-keri-witness-receipt-issue');
                })
                .catch(function (err)
                {
                    if (err.name === 'ConditionalCheckFailedException')
                    {
                        console.log('[keri-witness] duplicate event — already stored');
                        // Idempotent: already stored, still issue receipt
                        entityos.invoke('util-keri-witness-receipt-issue');
                    }
                    else
                    {
                        console.error('[keri-witness] PutItemCommand error:', err);
                        entityos.invoke('util-end',
                            entityos.invoke('util-response-json',
                                { body: { error: 'storage_error', message: err.message }, status: 500 }));
                    }
                });
            }
        });

        // ── 13. Issue witness receipt ─────────────────────────────────────────
        //
        // A KERI receipt (rct) is the witness's Ed25519 signature over the
        // event SAID, encoded in CESR, returned alongside the rct event stub.

        entityos.add(
        {
            name: 'util-keri-witness-receipt-issue',
            code: function ()
            {
                const keriEvent = entityos.get({ scope: 'keri-witness', context: 'inboundEvent' });
                const ws        = entityos.invoke('util-keri-witness-get-settings');

                const saidBuffer = Buffer.from(keriEvent.d, 'utf8');
                const rawPrivKey = ws.privateKey
                    ? entityos.invoke('util-keri-witness-cesr-key-decode', ws.privateKey)
                    : null;

                let witnessReceipt = null;

                if (rawPrivKey && ws.aid)
                {
                    const rawSig   = entityos.invoke('util-keri-witness-ed25519-sign',
                        { message: saidBuffer, privateKey: rawPrivKey });
                    const cesrSig  = entityos.invoke('util-keri-witness-cesr-sig-encode', rawSig);

                    witnessReceipt =
                    {
                        v:   'KERI10JSON00011c_',
                        t:   'rct',
                        d:   keriEvent.d,
                        i:   keriEvent.i,
                        s:   keriEvent.s,
                        // Coupler: witness AID + witness signature (CESR)
                        a:   [{ i: ws.aid, s: cesrSig }]
                    };
                }

                const responseBody =
                {
                    ok:          true,
                    said:        keriEvent.d,
                    aid:         keriEvent.i,
                    sn:          keriEvent.s,
                    eventType:   keriEvent.t,
                    witnessAid:  ws.aid || null,
                    receipt:     witnessReceipt,
                    dt:          new Date().toISOString()
                };

                entityos.invoke('util-end',
                    entityos.invoke('util-response-json', { body: responseBody, status: 200 }));
            }
        });

        // ── 14. Get full KEL from DynamoDB ────────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-kel-full-get',
            code: function ()
            {
                const aid    = entityos.get({ scope: 'keri-witness', context: 'queryAid' });
                const snStr  = entityos.get({ scope: 'keri-witness', context: 'querySn' });
                const ws     = entityos.invoke('util-keri-witness-get-settings');

                const { DynamoDBClient, QueryCommand } = require('@aws-sdk/client-dynamodb');
                const client = new DynamoDBClient(entityos.invoke('util-keri-witness-get-config'));

                const queryParams =
                {
                    TableName:              ws.table,
                    KeyConditionExpression: 'aid = :aid',
                    ExpressionAttributeValues: { ':aid': { S: aid } },
                    ScanIndexForward: true   // ascending sn order
                };

                // If specific sn requested, filter to that event
                if (snStr !== undefined)
                {
                    const snInt = parseInt(snStr, 16) || parseInt(snStr, 10) || 0;
                    queryParams.KeyConditionExpression += ' AND sn = :sn';
                    queryParams.ExpressionAttributeValues[':sn'] = { N: String(snInt) };
                }

                client.send(new QueryCommand(queryParams))
                .then(function (response)
                {
                    const events = (response.Items || []).map(function (item)
                    {
                        return JSON.parse(_.get(item, 'eventJson.S', '{}'));
                    });

                    if (!events.length)
                    {
                        entityos.invoke('util-end',
                            entityos.invoke('util-response-json',
                            {
                                body: { error: 'kel_not_found', aid: aid },
                                status: 404
                            }));
                        return;
                    }

                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                        {
                            body: { aid: aid, kel: events, count: events.length },
                            status: 200
                        }));
                })
                .catch(function (err)
                {
                    console.error('[keri-witness] QueryCommand (kel) error:', err);
                    entityos.invoke('util-end',
                        entityos.invoke('util-response-json',
                            { body: { error: 'storage_error', message: err.message }, status: 500 }));
                });
            }
        });

        // ─────────────────────────────────────────────────────────────────────
        // CRYPTO UTILITIES — no external deps, Node.js built-in crypto only
        // ─────────────────────────────────────────────────────────────────────

        // ── 15. Compute SAID (SHA-256 based, no blake3 dep) ──────────────────
        //
        // KERI SAID: set d field to '#' * 44, compact-JSON-serialize, SHA-256,
        // base64url-encode, prepend 'E'. The result is always 44 chars.

        entityos.add(
        {
            name: 'util-keri-witness-said-compute',
            code: function (eventObj)
            {
                var clone = JSON.parse(JSON.stringify(eventObj));
                clone.d = '#'.repeat(44);   // placeholder same length as real SAID

                var serialized = JSON.stringify(clone);
                var hash       = crypto.createHash('sha256')
                                       .update(Buffer.from(serialized, 'utf8'))
                                       .digest();

                // 'E' prefix + 43 chars base64url = 44-char SAID
                return 'E' + hash.toString('base64url').slice(0, 43);
            }
        });

        // ── 16. Decode CESR-encoded public key (1-char prefix, 32-byte key) ──
        //
        // CESR encodes 32-byte keys as:
        //   base64url(0x00 || rawKey)  →  44 chars,  first char = 'A'
        //   replace first char with type code ('B', 'D', 'E', ...)
        // Decoding: restore 'A', base64url-decode, drop lead byte.

        entityos.add(
        {
            name: 'util-keri-witness-cesr-key-decode',
            code: function (qb64)
            {
                if (!qb64 || qb64.length < 44) { return null; }
                try
                {
                    var b64  = 'A' + qb64.slice(1);            // restore original first char
                    var bytes = Buffer.from(b64, 'base64url'); // 33 bytes
                    return bytes.slice(1);                      // drop lead byte → 32 bytes
                }
                catch (e)
                {
                    console.log('[keri-witness] cesr-key-decode error:', e.message);
                    return null;
                }
            }
        });

        // ── 17. Decode CESR-encoded Ed25519 signature (2-char prefix '0B') ───
        //
        // CESR encodes 64-byte signatures as:
        //   base64url(0x00 0x00 || sig)  →  88 chars, first 2 chars = 'AA'
        //   replace first 2 chars with '0B'
        // Decoding: restore 'AA', base64url-decode, drop 2 lead bytes.

        entityos.add(
        {
            name: 'util-keri-witness-cesr-sig-decode',
            code: function (qb64)
            {
                if (!qb64 || qb64.length < 88) { return null; }
                try
                {
                    var b64   = 'AA' + qb64.slice(2);           // restore original first 2 chars
                    var bytes = Buffer.from(b64, 'base64url');  // 66 bytes
                    return bytes.slice(2);                       // drop 2 lead bytes → 64 bytes
                }
                catch (e)
                {
                    console.log('[keri-witness] cesr-sig-decode error:', e.message);
                    return null;
                }
            }
        });

        // ── 18. Encode CESR Ed25519 signature ────────────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-cesr-sig-encode',
            code: function (sigBuffer)
            {
                if (!sigBuffer || sigBuffer.length !== 64) { return null; }
                // Prepend 2 lead bytes, base64url encode, replace first 2 chars with '0B'
                var padded = Buffer.concat([Buffer.from([0x00, 0x00]), sigBuffer]);
                var b64    = padded.toString('base64url'); // 88 chars, starts with 'AA'
                return '0B' + b64.slice(2);
            }
        });

        // ── 19. Ed25519 verify (Node.js crypto, no deps) ─────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-ed25519-verify',
            code: function (param)
            {
                var message   = _.get(param, 'message');     // Buffer
                var signature = _.get(param, 'signature');   // Buffer, 64 bytes
                var publicKey = _.get(param, 'publicKey');   // Buffer, 32 bytes raw

                if (!message || !signature || !publicKey) { return false; }
                if (signature.length !== 64)               { return false; }
                if (publicKey.length !== 32)               { return false; }

                try
                {
                    // Wrap raw public key in DER SubjectPublicKeyInfo envelope
                    var keyDer  = Buffer.concat([DER_SPKI_PREFIX, publicKey]);
                    var keyObj  = crypto.createPublicKey({ key: keyDer, format: 'der', type: 'spki' });

                    return crypto.verify(null, message, keyObj, signature);
                }
                catch (e)
                {
                    console.log('[keri-witness] ed25519-verify error:', e.message);
                    return false;
                }
            }
        });

        // ── 20. Ed25519 sign (witness receipt signing) ────────────────────────

        entityos.add(
        {
            name: 'util-keri-witness-ed25519-sign',
            code: function (param)
            {
                var message    = _.get(param, 'message');    // Buffer
                var privateKey = _.get(param, 'privateKey'); // Buffer, 32-byte seed

                if (!message || !privateKey || privateKey.length !== 32) { return null; }

                try
                {
                    // Wrap raw seed in DER PKCS#8 envelope
                    var keyDer  = Buffer.concat([DER_PKCS8_PREFIX, privateKey]);
                    var keyObj  = crypto.createPrivateKey({ key: keyDer, format: 'der', type: 'pkcs8' });

                    return crypto.sign(null, message, keyObj);  // returns 64-byte Buffer
                }
                catch (e)
                {
                    console.log('[keri-witness] ed25519-sign error:', e.message);
                    return null;
                }
            }
        });

        // ── 21. Response helpers ──────────────────────────────────────────────

        entityos.add(
        {
            name: 'util-response-json',
            code: function (param)
            {
                return {
                    statusCode: _.get(param, 'status', 200),
                    headers:
                    {
                        'Content-Type':                 'application/json',
                        'Access-Control-Allow-Origin':  '*',
                        'Access-Control-Allow-Headers': 'Content-Type',
                        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
                    },
                    body: JSON.stringify(_.get(param, 'body', {}))
                };
            }
        });
    }
};
